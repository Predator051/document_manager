export class GroupUser {
	id: number;
	fullname: string;
	rank: string;
	birthday: string;
	education: string;
	groupId: number;
}
