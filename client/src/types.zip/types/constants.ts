export const DEFAULT_NAME_DB_CONNECION: string = "roadmap";
export const SESSION_LENGTH: number = 30;