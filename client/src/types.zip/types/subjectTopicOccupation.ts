export class SubjectTopicOccupation {
	id: number;
	number: number;
	title: string;
}
