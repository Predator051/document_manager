import { SubjectSelectPath } from "./subjectSelectPath";
import { GroupUserPresence } from "./groupUserPresence";

export class ClassEvent {
	id: number;
	date: Date;
	hours: number;
	place: string;
	groupId: number;
	selectPath: SubjectSelectPath;
	presences: GroupUserPresence[];
}
