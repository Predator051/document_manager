export class GroupUserMark {
	id: number;
	current: number;
	topic: number;
	subject: number;
}
