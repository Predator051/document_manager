export enum RequestType {
	MESSAGE = "message",
	INIT = "init",
	LOGIN = "login",
	GET_ALL_GROUPS = "get_all_groups",
	GET_ALL_GROUPS_TRAINING_TYPES = "get_all_groups_training_types",
	CREATE_GROUP = "create_group",
	GET_ALL_SUBJECTS = "get_all_subjects",
	UPDATE_SUBJECTS = "update_subjects",
	CREATE_CLASS = "create_class",
	GET_CLASS_BY_ID = "get_class_by_id",
	GET_GROUP_BY_ID = "get_group_by_id",
	GET_SUBJECT_BY_ID = "get_subject_by_id",
	UPDATE_CLASS = "update_class",
	GET_MY_CLASSES = "get_my_classes",
}

export enum RequestCode {
	RES_CODE_SUCCESS = 200,
	RES_CODE_INTERNAL_ERROR = 1,
	RES_CODE_NOT_AUTHORIZED = 2,
}

export class RequestMessage<T> {
	constructor(messageInfo: string, requestCode: RequestCode, data: T) {
		this.data = data;
		this.messageInfo = messageInfo;
		this.requestCode = requestCode;
	}
	messageInfo: string;
	requestCode: RequestCode;
	data: T;
	session: string;
}
