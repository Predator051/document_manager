import { SubjectTopic } from "./subjectTopic";

export class SubjectTrainingProgram {
	id: number;

	title: string;

	topics: SubjectTopic[];
}
