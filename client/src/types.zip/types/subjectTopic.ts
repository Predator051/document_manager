import { SubjectTopicOccupation } from "./subjectTopicOccupation";

export class SubjectTopic {
	id: number;
	number: number;
	title: string;
	occupation: SubjectTopicOccupation[];
}
