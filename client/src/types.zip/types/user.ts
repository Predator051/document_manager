export enum UserType {
	TEACHER,
	VIEWER,
}

export class User {
	constructor(id: number, session: string, login: string, password: string) {
		this.id = id;
		this.session = session;
		this.login = login;
		this.password = password;
		this.userType = UserType.TEACHER;
	}

	id: number;
	session: string;
	login: string;
	password: string;
	userType: UserType;

	public static EmptyUser(): User {
		return {
			id: 0,
			session: "",
			login: "",
			password: "",
			userType: UserType.TEACHER,
		};
	}
}
