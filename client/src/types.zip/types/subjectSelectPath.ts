export class SubjectSelectPath {
	id: number;
	subject: number;
	programTraining: number;
	topic: number;
	occupation: number;
}
